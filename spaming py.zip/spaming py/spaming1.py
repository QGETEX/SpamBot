import pyautogui
from time import sleep

msg = input("Enter Your Msg  >>  :")
num_msg = int(input("Enter The Num of message  >>  :"))
time_msg = float(input("Enter Your Time of message  >>  :"))

for num in range(num_msg + 1):
    pyautogui.typewrite(msg)
    sleep(time_msg)
    pyautogui.press("enter")
    sleep(time_msg)

